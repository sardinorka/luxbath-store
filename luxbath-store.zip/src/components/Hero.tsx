"use client";
import { motion } from "framer-motion";
import { ArrowLeft, Play } from "lucide-react";
import Link from "next/link";
import Image from "next/image";

export default function Hero() {
  return (
    <section className="relative min-h-screen w-full overflow-hidden hero-gradient">
      {/* Background Image */}
      <div className="absolute inset-0">
        <Image
          src="/images/hero-bathtub.jpg"
          alt="وان لاکچری"
          fill
          priority
          className="object-cover opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-ink via-ink/60 to-ink/20" />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-[1600px] mx-auto px-6 md:px-12 pt-40 pb-20 min-h-screen flex flex-col justify-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1 }}
          className="max-w-3xl"
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-px bg-gold" />
            <span className="text-xs text-gold tracking-[0.3em] uppercase">
              کالکشن ۱۴۰۴
            </span>
          </div>

          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-[1.1] mb-8 text-balance">
            هنرِ <span className="shine">آرامش</span>
            <br />
            در آغوش آب
          </h1>

          <p className="text-lg md:text-xl text-cream/70 max-w-xl mb-12 leading-relaxed">
            وان و جکوزی‌های دست‌ساز از مرغوب‌ترین متریال جهان. هر قطعه، یک شاهکار برای کسانی که به کمتر از بهترین راضی نیستند.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              href="/products"
              className="btn-gold px-8 py-4 rounded-full inline-flex items-center justify-center gap-2 group"
            >
              <span className="font-bold">مشاهده کالکشن</span>
              <ArrowLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" />
            </Link>
            <button className="btn-outline px-8 py-4 rounded-full inline-flex items-center justify-center gap-2">
              <Play className="w-4 h-4 fill-current" />
              <span>تماشای فیلم برند</span>
            </button>
          </div>
        </motion.div>

        {/* Bottom Stats */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-auto pt-16 grid grid-cols-3 gap-6 max-w-2xl border-t border-white/10"
        >
          <div>
            <div className="text-3xl md:text-4xl font-bold text-gold mb-1">۱۵+</div>
            <div className="text-xs text-cream/60">سال تجربه</div>
          </div>
          <div className="border-r border-white/10 pr-6">
            <div className="text-3xl md:text-4xl font-bold text-gold mb-1">۴۰۰+</div>
            <div className="text-xs text-cream/60">پروژه لاکچری</div>
          </div>
          <div className="border-r border-white/10 pr-6">
            <div className="text-3xl md:text-4xl font-bold text-gold mb-1">۱۰۰٪</div>
            <div className="text-xs text-cream/60">رضایت مشتری</div>
          </div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        animate={{ y: [0, 10, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 text-xs text-cream/40 tracking-widest flex flex-col items-center gap-2"
      >
        <span>اسکرول کنید</span>
        <div className="w-px h-10 bg-gradient-to-b from-gold to-transparent" />
      </motion.div>
    </section>
  );
}
