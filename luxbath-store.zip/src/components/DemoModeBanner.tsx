"use client";
import { useState } from "react";
import { X, AlertTriangle } from "lucide-react";

export default function DemoModeBanner() {
  const [visible, setVisible] = useState(true);
  if (!visible) return null;

  return (
    <div className="relative z-[60] bg-gold text-ink text-sm px-6 py-3 flex items-center justify-center gap-3 text-center">
      <AlertTriangle className="w-4 h-4 shrink-0" />
      <span>
        حالت دمو فعال است — محصولات از دیتابیس محلی نمایش داده می‌شوند. برای اتصال به فروشگاه واقعی ووکامرس،
        متغیرهای <code className="font-mono bg-ink/10 px-1 rounded">WC_STORE_URL</code>،{" "}
        <code className="font-mono bg-ink/10 px-1 rounded">WC_CONSUMER_KEY</code> و{" "}
        <code className="font-mono bg-ink/10 px-1 rounded">WC_CONSUMER_SECRET</code> را در فایل env تنظیم کنید.
      </span>
      <button onClick={() => setVisible(false)} className="shrink-0 hover:opacity-70">
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
