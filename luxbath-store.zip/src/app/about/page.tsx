import Navbar from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import Image from "next/image";
import { Award, Users, Gem, Wrench } from "lucide-react";

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-ink">
      <Navbar />

      {/* Hero */}
      <section className="pt-32 pb-20 px-6 md:px-12 max-w-[1600px] mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-px bg-gold" />
              <span className="text-xs text-gold tracking-[0.3em] uppercase">داستان ما</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-8 text-balance">
              میراثی از<br />
              <span className="shine">شکوه و آرامش</span>
            </h1>
            <p className="text-lg text-cream/70 leading-relaxed mb-6">
              لاکس‌باث در سال ۱۳۸۸ با یک رویا متولد شد: خلق فضاهایی که نه فقط حمام، بلکه پناهگاهی برای روح باشند. امروز، پس از بیش از ۱۵ سال تلاش بی‌وقفه، به یکی از معتبرترین برندهای وان و جکوزی لاکچری در ایران تبدیل شده‌ایم.
            </p>
            <p className="text-cream/60 leading-relaxed">
              فلسفه ما ساده است: بهترین متریال جهان، دستان هنرمند استادکاران، و عشقی بی‌پایان به کمال. هر محصولی که از کارگاه ما خارج می‌شود، حامل این سه ارزش بنیادین است.
            </p>
          </div>

          <div className="relative aspect-square rounded-3xl overflow-hidden luxury-border">
            <Image
              src="/images/hero-bathtub.jpg"
              alt="درباره لاکس‌باث"
              fill
              className="object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/60 to-transparent" />
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 bg-ink-2 border-y border-white/5">
        <div className="max-w-[1600px] mx-auto px-6 md:px-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { icon: Award, value: "۱۵+", label: "سال تجربه" },
              { icon: Users, value: "۴۰۰+", label: "پروژه موفق" },
              { icon: Gem, value: "۹۸٪", label: "رضایت مشتری" },
              { icon: Wrench, value: "۵۰+", label: "استادکار ماهر" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="w-16 h-16 rounded-full bg-gold/10 border border-gold/20 flex items-center justify-center mx-auto mb-4">
                  <stat.icon className="w-7 h-7 text-gold" />
                </div>
                <div className="text-4xl md:text-5xl font-bold text-gold mb-2">{stat.value}</div>
                <div className="text-sm text-cream/60">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-24 px-6 md:px-12 max-w-[1600px] mx-auto">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <div className="w-12 h-px bg-gold" />
            <span className="text-xs text-gold tracking-[0.3em] uppercase">ارزش‌های ما</span>
            <div className="w-12 h-px bg-gold" />
          </div>
          <h2 className="text-4xl md:text-5xl font-bold">
            آنچه ما را <span className="shine">متفاوت</span> می‌کند
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            {
              title: "کیفیت بی‌چون‌وچرا",
              desc: "از سنگ مرمر کارارا تا طلای ۲۴ عیار، تنها بهترین متریال جهان در محصولات ما جای دارد.",
            },
            {
              title: "هنر دست‌ساز",
              desc: "هر محصول توسط استادکاران با تجربه و با دقت میلی‌متری ساخته می‌شود. هیچ میانبری وجود ندارد.",
            },
            {
              title: "خدمات پس از فروش",
              desc: "گارانتی مادام‌العمر و تیم پشتیبانی اختصاصی، تضمین آرامش خاطر شماست.",
            },
          ].map((value, i) => (
            <div
              key={i}
              className="p-8 rounded-2xl luxury-border bg-ink-2/50 hover:border-gold/40 transition-colors"
            >
              <div className="text-5xl font-bold text-gold/20 mb-4">۰{i + 1}</div>
              <h3 className="text-2xl font-bold mb-4">{value.title}</h3>
              <p className="text-cream/60 leading-relaxed">{value.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <Footer />
    </main>
  );
}
