import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { CartProvider } from "@/context/CartContext";

export const metadata: Metadata = {
  title: "لاکس‌باث | وان و جکوزی لاکچری",
  description: "برند برتر وان و جکوزی لاکچری در ایران. تجربه‌ای بی‌نظیر از آرامش و شکوه.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-ink text-cream antialiased grain">
        <CartProvider>{children}</CartProvider>
      </body>
    </html>
  );
}
