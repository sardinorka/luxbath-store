import { listProducts, listCategories, isStoreLive } from "@/lib/products";
import Navbar from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import DemoModeBanner from "@/components/DemoModeBanner";
import AddToCartButton from "@/components/AddToCartButton";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function ProductsPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; search?: string }>;
}) {
  const { category, search } = await searchParams;

  const [allProducts, categories, storeLive] = await Promise.all([
    listProducts({ category, search }),
    listCategories(),
    isStoreLive(),
  ]);

  const formatPrice = (price: string) => {
    return new Intl.NumberFormat("fa-IR").format(Number(price) / 1000000) + " میلیون";
  };

  return (
    <main className="min-h-screen bg-ink">
      {!storeLive && <DemoModeBanner />}
      <Navbar />

      {/* Hero Section */}
      <section className="pt-32 pb-10 px-6 md:px-12 max-w-[1600px] mx-auto">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-px bg-gold" />
          <span className="text-xs text-gold tracking-[0.3em] uppercase">کالکشن</span>
        </div>
        <h1 className="text-5xl md:text-7xl font-bold mb-4">
          تمام <span className="shine">شاهکارها</span>
        </h1>
        <p className="text-cream/60 text-lg max-w-2xl">
          مجموعه کامل وان و جکوزی‌های لاکچری لاکس‌باث. هر محصول، یک داستان از شکوه و آرامش.
        </p>
        {search && (
          <p className="mt-4 text-sm text-cream/50">
            نتایج جستجو برای: <span className="text-gold">«{search}»</span>
          </p>
        )}
      </section>

      {/* Category filters */}
      {categories.length > 0 && (
        <section className="px-6 md:px-12 max-w-[1600px] mx-auto pb-10">
          <div className="flex flex-wrap gap-3">
            <Link
              href="/products"
              className={`px-5 py-2 rounded-full text-sm border transition-colors ${
                !category
                  ? "bg-gold text-ink border-gold font-bold"
                  : "border-white/10 text-cream/70 hover:border-gold hover:text-gold"
              }`}
            >
              همه محصولات
            </Link>
            {categories.map((c) => (
              <Link
                key={c.id}
                href={`/products?category=${encodeURIComponent(c.slug)}`}
                className={`px-5 py-2 rounded-full text-sm border transition-colors ${
                  category === c.slug
                    ? "bg-gold text-ink border-gold font-bold"
                    : "border-white/10 text-cream/70 hover:border-gold hover:text-gold"
                }`}
              >
                {c.name}
                {typeof c.count === "number" && (
                  <span className="opacity-60"> ({new Intl.NumberFormat("fa-IR").format(c.count)})</span>
                )}
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Products Grid */}
      <section className="pb-24 px-6 md:px-12 max-w-[1600px] mx-auto">
        {allProducts.length === 0 ? (
          <div className="text-center py-20 text-cream/50">محصولی یافت نشد.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {allProducts.map((product, i) => (
              <div key={product.id} className="group card-hover">
                <Link href={`/products/${product.slug}`} className="block">
                  <div className="relative product-image-wrap aspect-[4/5] rounded-2xl overflow-hidden mb-6 luxury-border">
                    {product.isNew && (
                      <div className="absolute top-4 right-4 z-10 px-3 py-1 rounded-full bg-gold text-ink text-xs font-bold">
                        جدید
                      </div>
                    )}
                    {!product.inStock && (
                      <div className="absolute top-4 left-4 z-10 px-3 py-1 rounded-full bg-ink/80 border border-white/20 text-cream text-xs font-bold">
                        ناموجود
                      </div>
                    )}
                    <Image
                      src={product.image}
                      alt={product.name}
                      fill
                      className="object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent opacity-60" />
                    <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                      <span className="text-xs text-cream/60 tracking-wider">{product.category}</span>
                      <div className="w-10 h-10 rounded-full bg-gold/10 backdrop-blur-md border border-gold/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <ArrowLeft className="w-4 h-4 text-gold" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-gold/70 tracking-[0.3em]">۰{i + 1}</span>
                      <div className="w-8 h-px bg-gold/30" />
                    </div>
                    <h3 className="text-2xl font-bold text-cream group-hover:text-gold transition-colors">
                      {product.name}
                    </h3>
                    <p className="text-sm text-cream/60 line-clamp-1">{product.tagline}</p>
                  </div>
                </Link>
                <div className="flex items-center justify-between pt-4 mt-2 border-t border-white/5">
                  <span className="text-lg font-bold text-gold">
                    {formatPrice(product.price)} <span className="text-xs text-cream/40">تومان</span>
                  </span>
                  <AddToCartButton product={product} variant="icon" />
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      <Footer />
    </main>
  );
}
