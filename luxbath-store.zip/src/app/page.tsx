import { db } from "@/db";
import { testimonials } from "@/db/schema";
import { listProducts, isStoreLive } from "@/lib/products";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import FeaturedProducts from "@/components/FeaturedProducts";
import AboutSection from "@/components/AboutSection";
import Testimonials from "@/components/Testimonials";
import Marquee from "@/components/Marquee";
import CTASection, { Footer } from "@/components/Footer";
import DemoModeBanner from "@/components/DemoModeBanner";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [allProducts, allTestimonials, storeLive] = await Promise.all([
    listProducts(),
    db.select().from(testimonials),
    isStoreLive(),
  ]);

  return (
    <main>
      {!storeLive && <DemoModeBanner />}
      <Navbar />
      <Hero />
      <Marquee />
      <FeaturedProducts products={allProducts} />
      <AboutSection />
      <Testimonials testimonials={allTestimonials} />
      <CTASection />
      <Footer />
    </main>
  );
}
