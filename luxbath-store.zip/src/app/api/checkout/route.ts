import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { isWooCommerceConfigured, createWcOrder } from "@/lib/woocommerce";

interface CheckoutItem {
  id: string;
  wooId?: number;
  name: string;
  slug: string;
  image: string;
  price: string;
  quantity: number;
}

interface CheckoutBody {
  items: CheckoutItem[];
  billing: {
    firstName: string;
    lastName: string;
    phone: string;
    email?: string;
    city: string;
    address: string;
    postalCode: string;
  };
  paymentMethod: "cod" | "bank-transfer";
  note?: string;
}

function generateOrderNumber() {
  const rand = Math.floor(1000 + Math.random() * 9000);
  return `LUX-${Date.now().toString().slice(-6)}${rand}`;
}

export async function POST(request: Request) {
  try {
    const body = (await request.json()) as CheckoutBody;

    if (!body.items?.length) {
      return NextResponse.json({ error: "سبد خرید خالی است" }, { status: 400 });
    }
    const { billing } = body;
    if (
      !billing?.firstName ||
      !billing?.lastName ||
      !billing?.phone ||
      !billing?.city ||
      !billing?.address ||
      !billing?.postalCode
    ) {
      return NextResponse.json({ error: "اطلاعات ارسال ناقص است" }, { status: 400 });
    }

    const total = body.items.reduce((sum, i) => sum + Number(i.price) * i.quantity, 0);
    const paymentTitle =
      body.paymentMethod === "cod" ? "پرداخت در محل" : "کارت به کارت / واریز بانکی";

    let wooOrderId: number | null = null;
    let orderNumber = generateOrderNumber();
    let status = "pending";
    let source = "demo";

    if (isWooCommerceConfigured()) {
      const lineItems = body.items
        .filter((i) => typeof i.wooId === "number")
        .map((i) => ({ product_id: i.wooId as number, quantity: i.quantity }));

      if (lineItems.length > 0) {
        try {
          const wcOrder = await createWcOrder({
            payment_method: body.paymentMethod === "cod" ? "cod" : "bacs",
            payment_method_title: paymentTitle,
            set_paid: false,
            billing: {
              first_name: billing.firstName,
              last_name: billing.lastName,
              address_1: billing.address,
              city: billing.city,
              postcode: billing.postalCode,
              country: "IR",
              email: billing.email || undefined,
              phone: billing.phone,
            },
            line_items: lineItems,
            customer_note: body.note,
          });
          wooOrderId = wcOrder.id;
          orderNumber = wcOrder.number || orderNumber;
          status = wcOrder.status;
          source = "woocommerce";
        } catch (err) {
          console.error("Failed to create WooCommerce order, saving locally instead:", err);
        }
      }
    }

    await db.insert(orders).values({
      orderNumber,
      wooOrderId,
      customerName: `${billing.firstName} ${billing.lastName}`,
      phone: billing.phone,
      email: billing.email,
      city: billing.city,
      address: billing.address,
      postalCode: billing.postalCode,
      paymentMethod: paymentTitle,
      note: body.note,
      items: body.items.map((i) => ({
        productId: i.wooId ?? 0,
        name: i.name,
        slug: i.slug,
        image: i.image,
        price: i.price,
        quantity: i.quantity,
      })),
      total: total.toFixed(2),
      status,
      source,
    });

    return NextResponse.json({ orderNumber, total, source, status });
  } catch (error) {
    console.error("Checkout failed:", error);
    return NextResponse.json({ error: "ثبت سفارش با خطا مواجه شد" }, { status: 500 });
  }
}
