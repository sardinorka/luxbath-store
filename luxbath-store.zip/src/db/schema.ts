import { pgTable, serial, text, integer, boolean, jsonb, timestamp, decimal } from "drizzle-orm/pg-core";

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  tagline: text("tagline").notNull(),
  description: text("description").notNull(),
  price: decimal("price", { precision: 12, scale: 2 }).notNull(),
  comparePrice: decimal("compare_price", { precision: 12, scale: 2 }),
  image: text("image").notNull(),
  gallery: jsonb("gallery").$type<string[]>().default([]).notNull(),
  category: text("category").notNull(),
  material: text("material"),
  dimensions: text("dimensions"),
  capacity: text("capacity"),
  features: jsonb("features").$type<string[]>().default([]).notNull(),
  isFeatured: boolean("is_featured").default(false).notNull(),
  isNew: boolean("is_new").default(false).notNull(),
  stock: integer("stock").default(0).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  authorName: text("author_name").notNull(),
  authorRole: text("author_role").notNull(),
  content: text("content").notNull(),
  rating: integer("rating").default(5).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Local order log. When WooCommerce is configured, orders are created there
// via the REST API and a copy is kept here for local record-keeping. When
// WooCommerce is not configured, this table is the sole source of truth
// (demo/sandbox mode).
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  wooOrderId: integer("woo_order_id"),
  customerName: text("customer_name").notNull(),
  phone: text("phone").notNull(),
  email: text("email"),
  city: text("city").notNull(),
  address: text("address").notNull(),
  postalCode: text("postal_code").notNull(),
  paymentMethod: text("payment_method").notNull(),
  note: text("note"),
  items: jsonb("items").$type<
    { productId: number; name: string; slug: string; image: string; price: string; quantity: number }[]
  >().notNull(),
  total: decimal("total", { precision: 14, scale: 2 }).notNull(),
  status: text("status").default("pending").notNull(),
  source: text("source").default("demo").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
