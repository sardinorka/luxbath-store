import "dotenv/config";
import { db } from "@/db";
import { products, testimonials } from "@/db/schema";

const seedProducts = [
  {
    name: "وان الماس",
    slug: "almas-bathtub",
    tagline: "شکوه مطلق در هر لمس",
    description:
      "وان الماس با الهام از معماری کلاسیک ایرانی و ساختاری مدرن، ترکیبی بی‌نظیر از سنگ مرمر کارارا و چوب گردوی آمریکایی است. هر قطعه از این وان توسط استادکاران ایتالیایی به صورت دست‌ساز ساخته می‌شود و امضای منحصر به فرد خالق خود را بر تن دارد.",
    price: "285000000",
    comparePrice: "340000000",
    image: "/images/products/almas.jpg",
    gallery: ["/images/products/almas.jpg", "/images/products/almas-2.jpg"],
    category: "وان مستقل",
    material: "سنگ مرمر کارارا",
    dimensions: "۱۸۰ × ۸۰ × ۶۵ سانتی‌متر",
    capacity: "۲۸۰ لیتر",
    features: [
      "سنگ مرمر طبیعی کارارا",
      "پایه‌های چوب گردوی دست‌ساز",
      "سیستم گرمایش هوشمند",
      "گارانتی مادام‌العمر",
    ],
    isFeatured: true,
    isNew: true,
    stock: 8,
  },
  {
    name: "جکوزی سافایر",
    slug: "sapphire-jacuzzi",
    tagline: "اقیانوس آرامش در خانه شما",
    description:
      "جکوزی سافایر با ۲۴ جت هیدروتراپی و سیستم نورپردازی کروماتراپی، تجربه‌ای بی‌نظیر از آرامش و سلامتی را به خانه شما می‌آورد. بدنه‌ای از آکرلیک تقویت‌شده با فایبرگلاس، برای سال‌ها استفاده بدون افت کیفیت.",
    price: "420000000",
    image: "/images/products/sapphire.jpg",
    gallery: ["/images/products/sapphire.jpg"],
    category: "جکوزی هیدروتراپی",
    material: "آکرلیک تقویت‌شده",
    dimensions: "۲۰۰ × ۲۰۰ × ۹۰ سانتی‌متر",
    capacity: "۴ نفره",
    features: [
      "۲۴ جت هیدروتراپی",
      "نورپردازی کروماتراپی",
      "سیستم تصفیه اوزون",
      "کنترل لمسی هوشمند",
    ],
    isFeatured: true,
    isNew: false,
    stock: 5,
  },
  {
    name: "وان سلطنتی پارس",
    slug: "pars-royal",
    tagline: "میراث پادشاهان، برای شما",
    description:
      "وان سلطنتی پارس با الهام از حمام‌های تاریخی کاخ‌های ایران، با روکش طلا و جزئیات دست‌ساز، شاهکاری است که هر حمامی را به قصر تبدیل می‌کند.",
    price: "580000000",
    image: "/images/products/pars.jpg",
    gallery: ["/images/products/pars.jpg"],
    category: "وان سلطنتی",
    material: "مس با روکش طلای ۲۴ عیار",
    dimensions: "۱۹۰ × ۸۵ × ۷۰ سانتی‌متر",
    capacity: "۳۰۰ لیتر",
    features: [
      "روکش طلای ۲۴ عیار",
      "نقش‌برجسته‌های دست‌ساز",
      "شیرآلات طلای ایتالیا",
      "گواهی اصالت هنری",
    ],
    isFeatured: true,
    isNew: true,
    stock: 3,
  },
  {
    name: "جکوزی اینفینیتی",
    slug: "infinity-jacuzzi",
    tagline: "بی‌نهایت در آغوش آب",
    description:
      "جکوزی اینفینیتی با طراحی مینیمال و لبه‌های بی‌نهایت، حس شناور بودن در اقیانوس را به شما هدیه می‌دهد. مناسب ویلاهای مدرن و فضاهای باز.",
    price: "365000000",
    image: "/images/products/infinity.jpg",
    gallery: ["/images/products/infinity.jpg"],
    category: "جکوزی فضای باز",
    material: "کامپوزیت پیشرفته",
    dimensions: "۲۲۰ × ۲۲۰ × ۸۵ سانتی‌متر",
    capacity: "۶ نفره",
    features: [
      "طراحی لبه بی‌نهایت",
      "مقاوم در برابر UV",
      "سیستم گرمایش خورشیدی",
      "کنترل از راه دور",
    ],
    isFeatured: false,
    isNew: false,
    stock: 7,
  },
  {
    name: "وان مینیمال نوردیک",
    slug: "nordic-minimal",
    tagline: "سادگی در اوج زیبایی",
    description:
      "وان مینیمال نوردیک با طراحی اسکاندیناوی، خطوط تمیز و متریال طبیعی، آرامشی خالص را به فضای حمام شما می‌آورد.",
    price: "195000000",
    image: "/images/products/nordic.jpg",
    gallery: ["/images/products/nordic.jpg"],
    category: "وان مستقل",
    material: "سنگ گرانیت سیاه",
    dimensions: "۱۷۰ × ۷۵ × ۶۰ سانتی‌متر",
    capacity: "۲۴۰ لیتر",
    features: [
      "سنگ گرانیت طبیعی",
      "طراحی اسکاندیناوی",
      "عایق حرارتی پیشرفته",
      "نصب آسان",
    ],
    isFeatured: false,
    isNew: true,
    stock: 12,
  },
  {
    name: "جکوزی پریمیوم رُز",
    slug: "rose-premium",
    tagline: "ظرافت زنانه در ابعاد لاکچری",
    description:
      "جکوزی پریمیوم رُز با طراحی منحنی و ظریف، و رنگ‌های ملایم پاستلی، انتخابی ایده‌آل برای فضاهای خصوصی و بوتیک‌هتل‌هاست.",
    price: "310000000",
    image: "/images/products/rose.jpg",
    gallery: ["/images/products/rose.jpg"],
    category: "جکوزی هیدروتراپی",
    material: "آکرلیک پریمیوم",
    dimensions: "۱۸۰ × ۱۸۰ × ۸۵ سانتی‌متر",
    capacity: "۳ نفره",
    features: [
      "۱۸ جت آروماتراپی",
      "پخش‌کننده اسانس",
      "نورپردازی قابل تنظیم",
      "موسیقی بلوتوثی",
    ],
    isFeatured: false,
    isNew: false,
    stock: 6,
  },
];

const seedTestimonials = [
  {
    authorName: "دکتر آرش محمدی",
    authorRole: "معمار ارشد، دفتر معماری آرتا",
    content:
      "وان الماس که برای پروژه ویلای لواسان استفاده کردیم، نقطه عطف کل طراحی بود. کیفیت ساخت و توجه به جزئیات در سطح جهانی است.",
    rating: 5,
  },
  {
    authorName: "سارا رضوی",
    authorRole: "مدیر بوتیک‌هتل ماهان",
    content:
      "تجربه مهمانان ما پس از نصب جکوزی سافایر دگرگون شد. خدمات پس از فروش تیم لاکس‌باث نیز بی‌نظیر است.",
    rating: 5,
  },
  {
    authorName: "مهندس کامران نوری",
    authorRole: "توسعه‌دهنده املاک لوکس",
    content:
      "در ۲۰ پروژه اخیرمان از محصولات این برند استفاده کرده‌ایم. همواره فراتر از انتظار ظاهر شده‌اند.",
    rating: 5,
  },
];

async function seed() {
  console.log("🌱 Seeding database...");

  await db.delete(testimonials);
  await db.delete(products);

  await db.insert(products).values(seedProducts);
  console.log(`✅ Inserted ${seedProducts.length} products`);

  await db.insert(testimonials).values(seedTestimonials);
  console.log(`✅ Inserted ${seedTestimonials.length} testimonials`);

  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
