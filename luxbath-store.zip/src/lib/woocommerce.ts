// Server-only WooCommerce REST API client.
// Docs: https://woocommerce.github.io/woocommerce-rest-api-docs/
import "server-only";

const STORE_URL = process.env.WC_STORE_URL?.replace(/\/+$/, "");
const CONSUMER_KEY = process.env.WC_CONSUMER_KEY;
const CONSUMER_SECRET = process.env.WC_CONSUMER_SECRET;

export function isWooCommerceConfigured(): boolean {
  return Boolean(STORE_URL && CONSUMER_KEY && CONSUMER_SECRET);
}

interface WcRequestOptions {
  method?: "GET" | "POST" | "PUT" | "DELETE";
  params?: Record<string, string | number | boolean | undefined>;
  body?: unknown;
}

export class WooCommerceError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
    this.name = "WooCommerceError";
  }
}

/**
 * Low-level request helper against the WooCommerce `wc/v3` REST API using
 * HTTP Basic Auth (consumer key / secret). Intended for server-side use only.
 */
export async function wcRequest<T>(
  endpoint: string,
  { method = "GET", params, body }: WcRequestOptions = {}
): Promise<T> {
  if (!isWooCommerceConfigured()) {
    throw new WooCommerceError("WooCommerce is not configured", 503);
  }

  const url = new URL(`${STORE_URL}/wp-json/wc/v3/${endpoint.replace(/^\/+/, "")}`);
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined) url.searchParams.set(key, String(value));
    }
  }

  const basicAuth = Buffer.from(`${CONSUMER_KEY}:${CONSUMER_SECRET}`).toString("base64");

  const res = await fetch(url.toString(), {
    method,
    headers: {
      Authorization: `Basic ${basicAuth}`,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
    cache: "no-store",
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new WooCommerceError(
      `WooCommerce API error (${res.status}): ${text.slice(0, 300)}`,
      res.status
    );
  }

  return res.json() as Promise<T>;
}

// ---- Raw WooCommerce types (subset of fields we use) ----

export interface WcImage {
  id: number;
  src: string;
  alt?: string;
}

export interface WcCategory {
  id: number;
  name: string;
  slug: string;
  count?: number;
  image?: WcImage | null;
}

export interface WcAttribute {
  id: number;
  name: string;
  options: string[];
}

export interface WcProduct {
  id: number;
  name: string;
  slug: string;
  permalink: string;
  description: string;
  short_description: string;
  price: string;
  regular_price: string;
  sale_price: string;
  on_sale: boolean;
  featured: boolean;
  status: string;
  stock_status: "instock" | "outofstock" | "onbackorder";
  stock_quantity: number | null;
  images: WcImage[];
  categories: WcCategory[];
  attributes: WcAttribute[];
  tags: { id: number; name: string; slug: string }[];
  date_created: string;
}

export interface WcLineItem {
  product_id: number;
  quantity: number;
}

export interface WcOrderPayload {
  payment_method: string;
  payment_method_title: string;
  set_paid: boolean;
  billing: {
    first_name: string;
    last_name: string;
    address_1: string;
    city: string;
    state?: string;
    postcode: string;
    country: string;
    email?: string;
    phone: string;
  };
  shipping?: WcOrderPayload["billing"];
  line_items: WcLineItem[];
  customer_note?: string;
}

export interface WcOrder {
  id: number;
  number: string;
  status: string;
  total: string;
  currency: string;
  date_created: string;
}

export async function getWcProducts(params?: {
  per_page?: number;
  page?: number;
  category?: string;
  search?: string;
  featured?: boolean;
  orderby?: string;
  order?: "asc" | "desc";
}): Promise<WcProduct[]> {
  return wcRequest<WcProduct[]>("products", {
    params: { status: "publish", per_page: 100, ...params },
  });
}

export async function getWcProductBySlug(slug: string): Promise<WcProduct | null> {
  const list = await wcRequest<WcProduct[]>("products", {
    params: { slug, status: "publish" },
  });
  return list[0] ?? null;
}

export async function getWcCategories(): Promise<WcCategory[]> {
  return wcRequest<WcCategory[]>("products/categories", {
    params: { per_page: 100, hide_empty: true },
  });
}

export async function createWcOrder(payload: WcOrderPayload): Promise<WcOrder> {
  return wcRequest<WcOrder>("orders", { method: "POST", body: payload });
}
