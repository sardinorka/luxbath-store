import "server-only";
import { db } from "@/db";
import { products as localProducts } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  isWooCommerceConfigured,
  getWcProducts,
  getWcProductBySlug,
  getWcCategories,
  type WcProduct,
} from "@/lib/woocommerce";
import type { StoreProduct, StoreCategory } from "@/lib/types";

function stripHtml(html: string): string {
  return html
    .replace(/<[^>]*>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function findAttribute(product: WcProduct, names: string[]): string | undefined {
  const attr = product.attributes?.find((a) =>
    names.some((n) => a.name?.toLowerCase().includes(n.toLowerCase()))
  );
  return attr?.options?.join("، ");
}

function mapWcProduct(p: WcProduct): StoreProduct {
  const description = stripHtml(p.description || "");
  const shortDescription = stripHtml(p.short_description || "");
  const isNewTag = p.tags?.some((t) => ["جدید", "new"].includes(t.name?.toLowerCase()));
  const createdRecently =
    p.date_created && Date.now() - new Date(p.date_created).getTime() < 1000 * 60 * 60 * 24 * 60;

  return {
    id: `wc-${p.id}`,
    source: "woocommerce",
    wooId: p.id,
    name: p.name,
    slug: p.slug,
    tagline: shortDescription || description.slice(0, 80),
    description: description || shortDescription,
    price: p.price || p.regular_price || "0",
    regularPrice: p.regular_price,
    onSale: p.on_sale,
    image: p.images?.[0]?.src || "/images/hero-bathtub.jpg",
    gallery: p.images?.map((img) => img.src) ?? [],
    category: p.categories?.[0]?.name || "بدون دسته",
    material: findAttribute(p, ["متریال", "جنس", "material"]),
    dimensions: findAttribute(p, ["ابعاد", "dimension"]),
    capacity: findAttribute(p, ["ظرفیت", "capacity"]),
    features: p.attributes?.flatMap((a) => a.options) ?? [],
    isFeatured: p.featured,
    isNew: Boolean(isNewTag || createdRecently),
    inStock: p.stock_status === "instock",
    stockQuantity: p.stock_quantity,
  };
}

function mapLocalProduct(p: typeof localProducts.$inferSelect): StoreProduct {
  return {
    id: `local-${p.id}`,
    source: "local",
    name: p.name,
    slug: p.slug,
    tagline: p.tagline,
    description: p.description,
    price: p.price,
    regularPrice: p.comparePrice ?? undefined,
    onSale: Boolean(p.comparePrice),
    image: p.image,
    gallery: p.gallery,
    category: p.category,
    material: p.material ?? undefined,
    dimensions: p.dimensions ?? undefined,
    capacity: p.capacity ?? undefined,
    features: p.features,
    isFeatured: p.isFeatured,
    isNew: p.isNew,
    inStock: p.stock > 0,
    stockQuantity: p.stock,
  };
}

export async function isStoreLive(): Promise<boolean> {
  return isWooCommerceConfigured();
}

export async function listProducts(filters?: {
  category?: string;
  search?: string;
}): Promise<StoreProduct[]> {
  if (isWooCommerceConfigured()) {
    try {
      let categoryId: string | undefined;
      if (filters?.category) {
        const cats = await getWcCategories();
        categoryId = cats.find((c) => c.slug === filters.category)?.id?.toString();
      }
      const wc = await getWcProducts({
        category: categoryId,
        search: filters?.search,
      });
      return wc.map(mapWcProduct);
    } catch (err) {
      console.error("WooCommerce fetch failed, falling back to local data:", err);
    }
  }

  const rows = await db.select().from(localProducts).orderBy(localProducts.createdAt);
  let mapped = rows.map(mapLocalProduct);

  if (filters?.category) {
    mapped = mapped.filter((p) => p.category === filters.category);
  }
  if (filters?.search) {
    const q = filters.search.toLowerCase();
    mapped = mapped.filter(
      (p) => p.name.toLowerCase().includes(q) || p.tagline.toLowerCase().includes(q)
    );
  }
  return mapped;
}

export async function listFeaturedProducts(): Promise<StoreProduct[]> {
  const all = await listProducts();
  const featured = all.filter((p) => p.isFeatured);
  return featured.length > 0 ? featured : all.slice(0, 3);
}

export async function getProductBySlug(slug: string): Promise<StoreProduct | null> {
  if (isWooCommerceConfigured()) {
    try {
      const wc = await getWcProductBySlug(slug);
      return wc ? mapWcProduct(wc) : null;
    } catch (err) {
      console.error("WooCommerce fetch failed, falling back to local data:", err);
    }
  }

  const [row] = await db.select().from(localProducts).where(eq(localProducts.slug, slug)).limit(1);
  return row ? mapLocalProduct(row) : null;
}

export async function listCategories(): Promise<StoreCategory[]> {
  if (isWooCommerceConfigured()) {
    try {
      const wc = await getWcCategories();
      return wc.map((c) => ({ id: `wc-${c.id}`, name: c.name, slug: c.slug, count: c.count }));
    } catch (err) {
      console.error("WooCommerce categories fetch failed, falling back to local data:", err);
    }
  }

  const rows = await db.select().from(localProducts);
  const set = new Map<string, number>();
  for (const r of rows) {
    set.set(r.category, (set.get(r.category) ?? 0) + 1);
  }
  return Array.from(set.entries()).map(([name, count]) => ({
    id: `local-${name}`,
    name,
    slug: name,
    count,
  }));
}
