# لاکس‌باث (LuxBath) — فروشگاه لاکچری وان و جکوزی

یک سایت فروشگاهی هدلس متصل به ووکامرس با طراحی لاکچری فارسی (RTL) ساخته‌شده با **Next.js 16**، **Tailwind CSS**، **Framer Motion** و **PostgreSQL**.

---

## ✨ ویژگی‌ها

- 🛒 سبد خرید کامل با ذخیره‌سازی محلی
- 💳 فرم تسویه‌حساب با ثبت سفارش در ووکامرس
- 🔗 اتصال مستقیم REST API به ووکامرس (حالت هدلس)
- 🎨 طراحی لاکچری تاریک با اکسنت طلایی
- 📱 کاملاً واکنش‌گرا (Responsive)
- 🔍 فیلتر دسته‌بندی و جستجوی محصولات
- 🇮🇷 فارسی RTL با فونت وزیر

---

## 🚀 دیپلوی روی Vercel (رایگان)

### پیش‌نیازها
- یک اکانت GitHub
- یک اکانت [Vercel](https://vercel.com) (رایگان)

### مراحل

**۱. آپلود روی GitHub**
```bash
git remote add origin https://github.com/YOUR_USERNAME/luxbath.git
git push -u origin master
```

**۲. اتصال به Vercel**
1. وارد [vercel.com](https://vercel.com) شوید
2. روی "New Project" بزنید
3. Repository خود را انتخاب کنید
4. در "Environment Variables" متغیرهای ووکامرس را اضافه کنید:
   - `WC_STORE_URL` = `https://yourstore.com`
   - `WC_CONSUMER_KEY` = `ck_...`
   - `WC_CONSUMER_SECRET` = `cs_...`
5. روی "Deploy" بزنید

**۳. تنظیم دامنه (اختیاری)**
در تنظیمات پروژه Vercel، یک دامنه `shop.yoursite.com` اضافه کنید و DNS را تنظیم کنید.

---

## 🖥️ دیپلوی روی سرور شخصی (VPS)

### نصب Node.js و PM2
```bash
# نصب Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# نصب PM2
sudo npm install -g pm2
```

### کلون و نصب
```bash
git clone https://github.com/YOUR_USERNAME/luxbath.git
cd luxbath
npm install
```

### ساخت فایل .env
```bash
cp .env .env.production
# فایل را ویرایش کنید و مقادیر واقعی را وارد کنید
nano .env.production
```

### بیلد و اجرا
```bash
npm run build
pm2 start npm --name "luxbath" -- start
pm2 save
pm2 startup
```

### تنظیم Nginx به‌عنوان Reverse Proxy
```nginx
server {
    listen 80;
    server_name shop.yoursite.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

```bash
sudo ln -s /etc/nginx/sites-available/shop.yoursite.com /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### SSL با Certbot
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d shop.yoursite.com
```

---

## ⚙️ تنظیمات ووکامرس

### ساخت کلید API
1. پیشخوان وردپرس → **WooCommerce → Settings → Advanced → REST API**
2. روی "Add key" بزنید
3. **Description:** `LuxBath Store`
4. **Permissions:** `Read/Write`
5. مقادیر `Consumer Key` و `Consumer Secret` را کپی کنید

### نگاشت محصولات
| فیلد سایت | ووکامرس |
|---|---|
| نام | `name` |
| قیمت | `price` |
| تصاویر | `images[]` |
| دسته‌بندی | `categories[0]` |
| ویژگی | Attributes: `جنس`, `ابعاد`, `ظرفیت` |
| جدید | برچسب «جدید» یا محصول در ۶۰ روز اخیر |

---

## 🛠️ توسعه محلی

```bash
# کلون پروژه
git clone https://github.com/YOUR_USERNAME/luxbath.git
cd luxbath

# نصب وابستگی‌ها
npm install

# اجرا
npm run dev
```

---

## 📁 ساختار پروژه

```
src/
├── app/                  # صفحات Next.js (App Router)
│   ├── api/              # API Routes
│   │   ├── products/     # GET /api/products
│   │   ├── checkout/     # POST /api/checkout
│   │   └── categories/   # GET /api/categories
│   ├── products/         # صفحه محصولات و جزئیات
│   ├── cart/             # سبد خرید
│   ├── checkout/         # تسویه‌حساب
│   └── order-success/     # تایید سفارش
├── components/           # کامپوننت‌های React
├── context/              # React Context (سبد خرید)
├── db/                   # Drizzle ORM + PostgreSQL
├── lib/                  # لایه‌های دسترسی به داده
│   ├── woocommerce.ts    # کلاینت REST API ووکامرس
│   ├── products.ts       # لایه یکپارچه محصولات
│   └── types.ts          # تایپ‌های TypeScript
└── public/images/        # تصاویر محصولات
```

---

## 📝 لایسنس

MIT License
